package com.zuhud.videoeditor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileInputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mengekspor proyek menjadi MP4 memakai Media3 Transformer:
 * potong + gabung + kecepatan + teks + musik, lalu simpan ke Movies/ZuhudVideoEditor.
 */
class Exporter(private val context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onDone(uri: Uri)
        fun onError(message: String)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var outFile: File? = null
    private var cancelled = false
    private var polling: Runnable? = null

    /**
     * @param shortSide sisi terpendek hasil (1080, 1440, 2160) atau 0 untuk resolusi asli klip pertama.
     * @param fps 0 = pertahankan FPS asli (default, gerakan paling natural). Nilai lain (30/60/120)
     *            hanya batas maksimum: frame berlebih dibuang, tetapi TIDAK ada frame interpolation
     *            atau frame generation, sehingga tidak ada ghosting. Sumber dengan fps lebih
     *            rendah tetap pada fps aslinya.
     * Harus dipanggil dari thread utama.
     */
    fun start(project: Project, shortSide: Int, fps: Int, cb: Callback) {
        val clips = project.clips.map { it.copy() }
        val texts = project.texts.map { it.copy() }
        val audio = project.audio
        val mute = project.muteOriginal
        if (clips.isEmpty()) {
            cb.onError("Tidak ada klip untuk diekspor")
            return
        }

        val file = File(context.cacheDir, "export_${System.currentTimeMillis()}.mp4")
        outFile = file
        cancelled = false

        try {
            val (outW, outH) = outputSize(clips.first(), shortSide)
            val totalMs = clips.sumOf { it.effectiveMs }

            // --- urutan video ---
            val videoItems = clips.map { c ->
                val mediaItem = MediaItem.Builder()
                    .setUri(c.uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(c.startMs)
                            .setEndPositionMs(c.endMs)
                            .build()
                    )
                    .build()
                val b = EditedMediaItem.Builder(mediaItem)
                    .setRemoveAudio(mute)
                // fps <= 0 berarti FPS asli: tidak ada batas, tidak ada frame yang dibuang atau dibuat.
                if (fps > 0) b.setFrameRate(fps)
                if (c.speed != 1f) b.setSpeed(ConstantSpeed(c.speed))
                b.build()
            }
            val videoSequence = if (mute) {
                EditedMediaItemSequence.withVideoFrom(videoItems)
            } else {
                EditedMediaItemSequence.withAudioAndVideoFrom(videoItems)
            }

            // --- musik latar (diulang sampai video selesai, dipotong bila lebih panjang) ---
            val audioSequence = audio?.let { a ->
                val mb = MediaItem.Builder().setUri(a.uri)
                if (a.durationMs > totalMs) {
                    mb.setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0)
                            .setEndPositionMs(totalMs)
                            .build()
                    )
                }
                val item = EditedMediaItem.Builder(mb.build()).build()
                EditedMediaItemSequence.withAudioFrom(listOf(item))
                    .buildUpon()
                    .setIsLooping(true)
                    .build()
            }

            // --- efek tingkat komposisi: ukuran hasil + teks ---
            val videoEffects = ArrayList<Effect>()
            videoEffects.add(
                Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT)
            )
            if (texts.isNotEmpty()) {
                videoEffects.add(
                    OverlayEffect(
                        ImmutableList.of<TextureOverlay>(TextTimelineOverlay(outW, outH, texts))
                    )
                )
            }
            val effects = Effects(listOf<AudioProcessor>(), videoEffects)

            val builder = if (audioSequence != null) {
                Composition.Builder(videoSequence, audioSequence)
            } else {
                Composition.Builder(videoSequence)
            }
            val composition = builder.setEffects(effects).build()

            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling()
                    saveToGallery(file, cb)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopPolling()
                    file.delete()
                    if (!cancelled) {
                        cb.onError("${exportException.errorCodeName}: ${exportException.message}")
                    }
                }
            }

            val videoMime =
                if (max(outW, outH) > 2000) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264

            val t = Transformer.Builder(context)
                .setVideoMimeType(videoMime)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(listener)
                .build()
            transformer = t
            t.start(composition, file.absolutePath)
            startPolling(t, cb)
        } catch (e: Exception) {
            file.delete()
            cb.onError(e.message ?: e.javaClass.simpleName)
        }
    }

    fun cancel() {
        cancelled = true
        stopPolling()
        try {
            transformer?.cancel()
        } catch (e: Exception) {
            // abaikan
        }
        outFile?.delete()
    }

    private fun startPolling(t: Transformer, cb: Callback) {
        val holder = ProgressHolder()
        val r = object : Runnable {
            override fun run() {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    cb.onProgress(holder.progress)
                }
                handler.postDelayed(this, 300)
            }
        }
        polling = r
        handler.post(r)
    }

    private fun stopPolling() {
        polling?.let { handler.removeCallbacks(it) }
        polling = null
    }

    private fun outputSize(first: Clip, shortSide: Int): Pair<Int, Int> {
        val w = first.width
        val h = first.height
        if (shortSide <= 0) return even(w) to even(h)
        return if (w >= h) {
            val oh = shortSide
            val ow = even((oh.toFloat() * w / h).roundToInt())
            ow to oh
        } else {
            val ow = shortSide
            val oh = even((ow.toFloat() * h / w).roundToInt())
            ow to oh
        }
    }

    private fun even(v: Int): Int = max(2, v / 2 * 2)

    /** Menyalin hasil dari cache ke galeri (Movies/ZuhudVideoEditor) di thread terpisah. */
    private fun saveToGallery(file: File, cb: Callback) {
        Thread {
            try {
                val resolver = context.contentResolver
                val name = "Zuhud_${System.currentTimeMillis()}.mp4"
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/ZuhudVideoEditor"
                    )
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Gagal membuat berkas di galeri")
                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input -> input.copyTo(out) }
                } ?: throw IllegalStateException("Gagal menulis berkas")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                file.delete()
                handler.post { cb.onDone(uri) }
            } catch (e: Exception) {
                file.delete()
                handler.post { cb.onError(e.message ?: "Gagal menyimpan hasil") }
            }
        }.start()
    }
}

/** Kecepatan tetap untuk satu klip. */
private class ConstantSpeed(private val speed: Float) : SpeedProvider {
    override fun getSpeed(timeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
}

/**
 * Overlay teks berbasis bitmap seukuran frame hasil, sehingga posisinya selalu tepat
 * (teks di bagian bawah tengah). Teks yang aktif diambil dari waktu timeline.
 */
private class TextTimelineOverlay(
    private val w: Int,
    private val h: Int,
    private val texts: List<TextItem>
) : BitmapOverlay() {

    private val empty: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    private var lastKey: String? = null
    private var lastBitmap: Bitmap = empty

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val active = texts.filter { ms >= it.startMs && ms < it.endMs }
        if (active.isEmpty()) return empty

        val joined = active.joinToString("\n") { it.text }
        if (joined == lastKey) return lastBitmap

        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val size = min(w, h) * 0.07f
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = size
        paint.typeface = Typeface.DEFAULT_BOLD
        val layoutWidth = (w * 0.86f).toInt()
        val layout = StaticLayout.Builder.obtain(joined, 0, joined.length, paint, layoutWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()

        canvas.save()
        canvas.translate((w - layoutWidth) / 2f, h * 0.86f - layout.height)
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = size * 0.16f
        paint.color = 0xFF000000.toInt()
        layout.draw(canvas)
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        layout.draw(canvas)
        canvas.restore()

        lastKey = joined
        lastBitmap = bmp
        return bmp
    }
}
