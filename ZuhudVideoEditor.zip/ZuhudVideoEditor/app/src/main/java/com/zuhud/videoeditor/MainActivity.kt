package com.zuhud.videoeditor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val io = Executors.newSingleThreadExecutor()
    private lateinit var btnContinue: Button
    private lateinit var txtInfo: TextView

    private val pickVideos =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) startNewProject(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnContinue = findViewById(R.id.btnContinue)
        txtInfo = findViewById(R.id.txtInfo)

        findViewById<Button>(R.id.btnNew).setOnClickListener {
            pickVideos.launch(arrayOf("video/*"))
        }
        btnContinue.setOnClickListener {
            startActivity(Intent(this, EditorActivity::class.java))
        }
        findViewById<Button>(R.id.btnMeta).setOnClickListener {
            startActivity(Intent(this, MetaSoundActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        val hasProject = ProjectStore.project.clips.isNotEmpty()
        btnContinue.visibility = if (hasProject) android.view.View.VISIBLE else android.view.View.GONE
        val pending = ProjectStore.pendingAudio
        txtInfo.text = if (pending != null) {
            "Musik siap dipakai: ${pending.name}"
        } else {
            ""
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    private fun startNewProject(uris: List<Uri>) {
        Toast.makeText(this, "Memuat video…", Toast.LENGTH_SHORT).show()
        io.execute {
            val clips = uris.mapNotNull { uri ->
                MediaUtil.keepAccess(this, uri)
                MediaUtil.probeVideo(this, uri)
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (clips.isEmpty()) {
                    Toast.makeText(this, "Video tidak dapat dibaca", Toast.LENGTH_LONG).show()
                } else {
                    val project = Project()
                    project.clips.addAll(clips)
                    ProjectStore.project = project
                    startActivity(Intent(this, EditorActivity::class.java))
                }
            }
        }
    }
}
