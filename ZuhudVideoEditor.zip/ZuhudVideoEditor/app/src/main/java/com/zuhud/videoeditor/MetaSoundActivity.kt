package com.zuhud.videoeditor

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors

/**
 * Membuka halaman resmi Meta (Facebook) Sound Collection di WebView.
 * Pengguna login dengan akunnya sendiri, mencari dan mengunduh lewat fitur resmi halaman tersebut.
 * Berkas yang terunduh bisa diimpor ke editor. Tidak ada API tidak resmi atau scraping.
 */
class MetaSoundActivity : AppCompatActivity() {

    companion object {
        const val SOUND_URL = "https://www.facebook.com/sound/collection/"
    }

    private lateinit var web: WebView
    private lateinit var pageProgress: ProgressBar
    private lateinit var downloadList: LinearLayout
    private lateinit var dm: DownloadManager
    private val io = Executors.newSingleThreadExecutor()
    private var receiverRegistered = false

    private val pickAudio =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                MediaUtil.keepAccess(this, uri)
                importAudio(uri)
            }
        }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != -1L) onDownloadFinished(id)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meta_sound)

        dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        web = findViewById(R.id.webView)
        pageProgress = findViewById(R.id.pageProgress)
        downloadList = findViewById(R.id.downloadList)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnBrowser).setOnClickListener { openInBrowser() }
        findViewById<Button>(R.id.btnFile).setOnClickListener { pickAudio.launch(arrayOf("audio/*")) }

        setupWebView()
        web.loadUrl(SOUND_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        ContextCompat.registerReceiver(
            this, receiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),
            ContextCompat.RECEIVER_EXPORTED
        )
        receiverRegistered = true
    }

    override fun onDestroy() {
        super.onDestroy()
        if (receiverRegistered) unregisterReceiver(receiver)
        io.shutdownNow()
        web.stopLoading()
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
    }

    private fun setupWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: return true
                // Tetap di dalam WebView untuk http(s); blokir skema aplikasi lain (fb://, intent://).
                return !(scheme == "https" || scheme == "http")
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                pageProgress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageProgress.visibility = View.INVISIBLE
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                pageProgress.progress = newProgress
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            startDownload(url, userAgent, contentDisposition, mimetype)
        }
    }

    private fun startDownload(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimetype: String?
    ) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Unduhan ini tidak bisa ditangani di dalam aplikasi. Buka lewat Browser, lalu gunakan Pilih File.")
            return
        }
        try {
            val guessed = URLUtil.guessFileName(url, contentDisposition, mimetype)
            val fileName = "${System.currentTimeMillis()}_$guessed"
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(guessed)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_MUSIC, fileName)
            if (!mimetype.isNullOrBlank()) req.setMimeType(mimetype)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (!userAgent.isNullOrBlank()) req.addRequestHeader("User-Agent", userAgent)
            dm.enqueue(req)
            toast("Mengunduh $guessed…")
        } catch (e: Exception) {
            toast("Gagal mengunduh: ${e.message}")
        }
    }

    private fun onDownloadFinished(id: Long) {
        val q = DownloadManager.Query().setFilterById(id)
        dm.query(q)?.use { c ->
            if (!c.moveToFirst()) return
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            if (status != DownloadManager.STATUS_SUCCESSFUL) {
                toast("Unduhan gagal")
                return
            }
            val local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
            val path = Uri.parse(local).path ?: return
            addDownloadedRow(File(path))
        }
    }

    private fun addDownloadedRow(file: File) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val label = TextView(this).apply {
            text = "✔ " + file.name.substringAfter('_')
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val btn = Button(this).apply {
            text = "Impor"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            isAllCaps = false
            minWidth = 0
            minHeight = 0
            setPadding(dp(16), 0, dp(16), 0)
            setBackgroundResource(R.drawable.bg_btn_primary)
            stateListAnimator = null
            setOnClickListener { importAudio(Uri.fromFile(file)) }
        }
        row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)))
        downloadList.addView(row)
    }

    private fun importAudio(uri: Uri) {
        io.execute {
            val track = MediaUtil.probeAudio(this, uri)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (track == null) {
                    toast("Berkas audio tidak dapat dibaca")
                } else {
                    ProjectStore.pendingAudio = track
                    setResult(RESULT_OK)
                    toast("Musik siap: ${track.name}")
                    finish()
                }
            }
        }
    }

    private fun openInBrowser() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SOUND_URL)))
        } catch (e: Exception) {
            toast("Tidak ada browser yang tersedia")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
