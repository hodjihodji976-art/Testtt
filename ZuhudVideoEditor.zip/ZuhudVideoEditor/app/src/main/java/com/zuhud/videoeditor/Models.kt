package com.zuhud.videoeditor

import android.net.Uri

/** Satu klip video di timeline. width/height sudah memperhitungkan rotasi. */
data class Clip(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    var startMs: Long = 0L,
    var endMs: Long = durationMs,
    var speed: Float = 1f
) {
    /** Durasi klip di timeline setelah dipotong dan diatur kecepatannya. */
    val effectiveMs: Long
        get() = ((endMs - startMs) / speed).toLong().coerceAtLeast(1L)
}

/** Teks di atas video. Waktu dalam milidetik pada timeline hasil akhir. */
data class TextItem(
    var text: String,
    var startMs: Long,
    var durationMs: Long
) {
    val endMs: Long get() = startMs + durationMs
}

data class AudioTrack(
    val uri: Uri,
    val name: String,
    val durationMs: Long
)

class Project {
    val clips = mutableListOf<Clip>()
    val texts = mutableListOf<TextItem>()
    var audio: AudioTrack? = null
    var muteOriginal: Boolean = false

    val totalMs: Long get() = clips.sumOf { it.effectiveMs }
}

/** Penyimpan proyek di memori (sederhana, tanpa database). */
object ProjectStore {
    var project: Project = Project()

    /** Musik hasil unduhan Meta Sound Collection yang menunggu diimpor oleh editor. */
    var pendingAudio: AudioTrack? = null
}
